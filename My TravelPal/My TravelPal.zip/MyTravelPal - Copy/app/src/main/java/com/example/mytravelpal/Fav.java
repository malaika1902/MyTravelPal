package com.example.mytravelpal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Fav extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav);


        BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.Fav);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem menuitem) {
                switch (menuitem.getItemId()) {
                    case R.id.Home1:
                        startActivity(new Intent(getApplicationContext(), Activity2.class));
                        finish();
                        overridePendingTransition(0, 0);
                        return;
                    case R.id.Fav:


                    case R.id.AB:
                        startActivity(new Intent(getApplicationContext(), Abo.class));
                        finish();
                        overridePendingTransition(0, 0);
                        return;
                }
            }
        });

        final EditText edit1 = (EditText)findViewById(R.id.edit1);
        final EditText edit2 = (EditText)findViewById(R.id.edit2);
        Button btn = (Button)findViewById(R.id.bt);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/html");
                i.putExtra(android.content.Intent.EXTRA_EMAIL,new String[] { "chetan_scsebtech@galgotiasuniversity.edu.in" });
                i.putExtra(Intent.EXTRA_SUBJECT,"Feedback");
                i.putExtra(Intent.EXTRA_TEXT,"Name"+edit1.getText()+"\n Message:"+edit2.getText());
                try {
                    startActivity(Intent.createChooser(i,"Please select Email"));
                }
                catch (android.content.ActivityNotFoundException ex)
                {
                    Toast.makeText(Fav.this,"There is no Email Clients",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
