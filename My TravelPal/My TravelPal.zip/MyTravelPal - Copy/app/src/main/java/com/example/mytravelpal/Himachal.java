package com.example.mytravelpal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class Himachal extends AppCompatActivity {
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    RecyclerViewAdapter_him recyclerViewAdapter_him;
    int []arr ={R.drawable.manali,R.drawable.shimla,R.drawable.kangra,R.drawable.chamba};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_himachal);
        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerViewAdapter_him = new RecyclerViewAdapter_him(arr);

        recyclerView.setAdapter(recyclerViewAdapter_him);

        recyclerView.setHasFixedSize(true);

    }
}

