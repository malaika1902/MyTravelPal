package com.example.mytravelpal;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MyViewHolder  {
    ImageView img;
    TextView txt;
    public MyViewHolder(View view) {


        img = view.findViewById(R.id.imageView);
        txt = view.findViewById(R.id.textView);

    }

}
