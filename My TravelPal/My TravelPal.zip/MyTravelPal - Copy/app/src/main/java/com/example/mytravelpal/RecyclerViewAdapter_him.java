package com.example.mytravelpal;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter_him extends RecyclerView.Adapter<RecyclerViewAdapter_him.MyViewHolder> {
    int [] arr;

    public RecyclerViewAdapter_him(int[] arr) {
        this.arr = arr;
    }
    @NonNull
    @Override
    public RecyclerViewAdapter_him.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view,parent,false);
        RecyclerViewAdapter_him.MyViewHolder myViewHolder = new RecyclerViewAdapter_him.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter_him.MyViewHolder holder,final int position) {
        holder.imageView.setImageResource(arr[position]);
        //enter text or city name
        if(position == 0) {
            holder.textView.setText("Manali");
        }
        else if(position ==1){
            holder.textView.setText("Shimla");
        }
        else if(position ==2){
            holder.textView.setText("Kangra");
        }
        else if(position ==3){
            holder.textView.setText("Chamba");
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // open activity
                if(position == 0){
                    Intent intent = new Intent(v.getContext(),Manali.class);
                    v.getContext().startActivity(intent);
                }
                if(position == 1){
                    Intent intent = new Intent(v.getContext(),Shimla.class);
                    v.getContext().startActivity(intent);
                }
                if(position == 2){
                    Intent intent = new Intent(v.getContext(),Kangra.class);
                    v.getContext().startActivity(intent);
                }if(position == 3){
                    Intent intent = new Intent(v.getContext(),Chamba.class);
                    v.getContext().startActivity(intent);
                }

            }
        });
    }



    @Override
    public int getItemCount() {
        return arr.length;
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.imageView);
            textView=itemView.findViewById(R.id.textView);
        }
    }
}
