package com.example.mytravelpal;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter_sik extends RecyclerView.Adapter<RecyclerViewAdapter_sik.MyViewHolder> {
    int [] arr;

    public RecyclerViewAdapter_sik(int[] arr) {
        this.arr = arr;
    }
    @NonNull
    @Override
    public RecyclerViewAdapter_sik.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_view,parent,false);
        RecyclerViewAdapter_sik.MyViewHolder myViewHolder = new RecyclerViewAdapter_sik.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter_sik.MyViewHolder holder,final int position) {
        holder.imageView.setImageResource(arr[position]);
        //enter text or city name
        if(position == 0) {
            holder.textView.setText("Gangtok");
        }
        else if(position ==1){
            holder.textView.setText("Khangchendz-onga National Park");
        }
        else if(position ==2){
            holder.textView.setText("Yumthang");
        }
        else if(position ==3){
            holder.textView.setText("Namchi");
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // open activity
                if(position == 0){
                    Intent intent = new Intent(v.getContext(),Gangtok.class);
                    v.getContext().startActivity(intent);
                }
                if(position == 1){
                    Intent intent = new Intent(v.getContext(),Khanchan.class);
                    v.getContext().startActivity(intent);
                }
                if(position == 2){
                    Intent intent = new Intent(v.getContext(),Yumthang.class);
                    v.getContext().startActivity(intent);
                }
                if(position == 3){
                    Intent intent = new Intent(v.getContext(),Namchi.class);
                    v.getContext().startActivity(intent);
                }
            }
        });
    }



    @Override
    public int getItemCount() {
        return arr.length;
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.imageView);
            textView=itemView.findViewById(R.id.textView);
        }
    }
}
