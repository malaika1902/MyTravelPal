package com.example.mytravelpal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class Mumbai extends AppCompatActivity {
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    RecyclerViewAdapter_mum recyclerViewAdapter_mum;
    int []arr ={R.drawable.gateway,R.drawable.cst,R.drawable.marine,R.drawable.elephanta};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mumbai);
        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerViewAdapter_mum = new RecyclerViewAdapter_mum(arr);

        recyclerView.setAdapter(recyclerViewAdapter_mum);

        recyclerView.setHasFixedSize(true);

    }
}

