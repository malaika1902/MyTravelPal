package com.example.mytravelpal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Abo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abo);
        BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.AB);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem menuitem) {
                switch (menuitem.getItemId()) {
                    case R.id.Home1:
                        startActivity(new Intent(getApplicationContext(), Activity2.class));
                        finish();
                        overridePendingTransition(0, 0);
                        return;
                    case R.id.Fav:
                        startActivity(new Intent(getApplicationContext(), Fav.class));
                        finish();
                        overridePendingTransition(0, 0);
                        return;


                    case R.id.AB:

                }
            }
        });
    }
}

