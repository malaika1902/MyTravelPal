package com.example.mytravelpal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class Sikkim extends AppCompatActivity {
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    RecyclerViewAdapter_sik recyclerViewAdapter_sik;
    int []arr ={R.drawable.gangtok,R.drawable.khanchan,R.drawable.yumthang,R.drawable.namchi};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sikkim);
        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerViewAdapter_sik = new RecyclerViewAdapter_sik(arr);

        recyclerView.setAdapter(recyclerViewAdapter_sik);

        recyclerView.setHasFixedSize(true);

    }
}

