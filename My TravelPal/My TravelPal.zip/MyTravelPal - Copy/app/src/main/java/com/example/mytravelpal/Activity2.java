package com.example.mytravelpal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Activity2 extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        BottomNavigationView bottomNavigationView = (BottomNavigationView)findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.Home1);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
                                                                       @Override
                                                                       public void onNavigationItemReselected(@NonNull MenuItem menuitem) {
                                                                           switch (menuitem.getItemId()) {
                                                                               case R.id.Home1:

                                                                               case R.id.Fav:
                                                                                   startActivity(new Intent(getApplicationContext(), Fav.class));
                                                                                   finish();
                                                                                   overridePendingTransition(0, 0);
                                                                                   return;

                                                                               case R.id.AB:
                                                                                   startActivity(new Intent(getApplicationContext(), Abo.class));
                                                                                   finish();
                                                                                   overridePendingTransition(0, 0);
                                                                                   return;
                                                                           }
                                                                       }
                                                                   });


            listView = findViewById(R.id.listView1);
        MyAdapter adapter = new MyAdapter(this, getData());
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position == 0) {
                    Intent intent = new Intent(Activity2.this, Delhi.class);
                    startActivity(intent);
                }
                if (position == 1) {
                    Intent intent = new Intent(Activity2.this,Himachal.class);
                    startActivity(intent);
                }
                if (position == 3) {
                    Intent intent = new Intent(Activity2.this,Mumbai.class);
                    startActivity(intent);
                }
                if (position == 2) {
                    Intent intent = new Intent(Activity2.this,Sikkim.class);
                    startActivity(intent);
                }
            }
        });
    }



    private ArrayList<Data> getData() {
        ArrayList<Data> data= new ArrayList<>();
        Data d=new Data(R.drawable.del,"NEW DELHI");
        data.add(d);
        d=new Data(R.drawable.him,"HIMACHAL PRADESH");
        data.add(d);
        d=new Data(R.drawable.sik,"SIKKIM");
        data.add(d);
        d=new Data(R.drawable.mum,"MUMBAI");
        data.add(d);
        return data;
    }
}
